-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 20, 2023 at 11:50 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbtcg`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblnguoidung`
--

CREATE TABLE `tblnguoidung` (
  `TaiKhoan` varchar(50) NOT NULL,
  `HoTen` varchar(300) NOT NULL,
  `MatKhau` varchar(500) NOT NULL,
  `Quyen` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tblnguoidung`
--

INSERT INTO `tblnguoidung` (`TaiKhoan`, `HoTen`, `MatKhau`, `Quyen`) VALUES
('Quang', 'Phan Thanh Quang', '$2y$10$ErC/2fDXMfjKfnjA07HVOOkjQkbjJdglLyTE3VlbhccNuyEEQsh1m', 'Admin'),
('ThayTri', 'Văn Bá Trí', '$2y$10$MBC.DO2hGDqf2y/PBQK78u/lfWAsiEn1xhi2DB4B/Pg8avB5hgE9W', 'Admin');

-- --------------------------------------------------------

--
-- Table structure for table `tblsanpham`
--

CREATE TABLE `tblsanpham` (
  `Ma` int(11) NOT NULL,
  `AnhSP` varchar(500) NOT NULL,
  `TenSP` varchar(200) NOT NULL,
  `GiaSP` int(11) NOT NULL DEFAULT 0,
  `HangTon` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tblsanpham`
--

INSERT INTO `tblsanpham` (`Ma`, `AnhSP`, `TenSP`, `GiaSP`, `HangTon`) VALUES
(0, 'https://saigontcg.com/wp-content/uploads/RA01-EN069SR.jpg', 'RA01-EN069 – Compulsory', 20000, 1),
(2, 'https://saigontcg.com/wp-content/uploads/RA01-EN068UR.jpg', 'RA01-EN068 – Magician’s ', 25000, 3),
(3, 'https://saigontcg.com/wp-content/uploads/RA01-EN067UR.jpg', 'RA01-EN067 – Small World – Ultra Rare – 1st Edition', 50000, 1),
(4, 'https://saigontcg.com/wp-content/uploads/RA01-EN065UR.jpg', 'RA01-EN065 – Chaos Space – Ultra Rare – 1st Edition', 20000, 2),
(5, 'https://saigontcg.com/wp-content/uploads/RA01-EN064UTR.jpg', 'RA01-EN064 – Forbidden Droplet – Prismatic Ultimate Rare – 1st Edition', 420000, 6),
(6, 'https://saigontcg.com/wp-content/uploads/RA01-EN062QTR.jpg', 'RA01-EN062 – Nadir Serva', 480000, 1),
(7, 'https://saigontcg.com/wp-content/uploads/RA01-EN079UR.jpg', 'RA01-EN079 – Tri-Brigade', 20000, 4),
(9, 'https://saigontcg.com/wp-content/uploads/kico-en006.gif', 'KICO-EN006 – Thundersp', 15000, 4),
(10, 'https://saigontcg.com/wp-content/uploads/RA01-EN046UR.jpg', 'RA01-EN046 – Striker Drag', 50000, 7),
(13, 'anh/YS15-ENF00.jpeg', 'YS15-ENF00 – Odd-Eyes Saber Dragon – Secret Rare – 1st Edition', 80000, 1),
(23, 'https://saigontcg.com/wp-content/uploads/SBC1-ENI05.jpg', 'SBC1-ENI05 – Gearfried the Red-Eyes Iron Knight – Common – 1st Edition', 10000, 2),
(27, 'anh/SDMP-EN026.jpeg', 'SDMP-EN026 – Pendulum Call – Common – 1st Edition', 20000, 5),
(30, 'anh/SDMP-EN026123.jpeg', 'SPWA-EN047 – Honest – Super Rare – 1st Edition', 25000, 3),
(31, 'anh/RA01-EN024SR.jpg', 'RA01-EN024 – Cyber Angel Benten – Super Rare – 1st Edition', 18000, 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblnguoidung`
--
ALTER TABLE `tblnguoidung`
  ADD PRIMARY KEY (`TaiKhoan`);

--
-- Indexes for table `tblsanpham`
--
ALTER TABLE `tblsanpham`
  ADD PRIMARY KEY (`Ma`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblsanpham`
--
ALTER TABLE `tblsanpham`
  MODIFY `Ma` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
