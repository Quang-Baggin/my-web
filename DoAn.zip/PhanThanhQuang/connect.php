<?php
	$link=new mysqli("localhost", "root", "", "dbtcg")or die("Kết nối cơ sở dữ liệu ko thành công");

?>