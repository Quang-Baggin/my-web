<!doctype html>
<html><head>
<meta charset="utf-8">
<title>Untitled Document</title>
	
	
	<style>
		table, th, tr{
			border: 1px solid black;
			border-collapse: collapse;
		}
		th{
			background-color:#47a9f7;
			font-size: 35px;
			color: aliceblue;
		}
		.td{
			font-size: 20px;
			width: 300px;
			height: 50px;
		}
		.Text{
			width: 250px;
			height: 30px;
		}
		#tb{
			font-size: 18px;
			color: red;
			text-align: center;
			margin: auto
		}
		#nut{
			padding: 20px;
			background-color: #78C0F9;
			color: aliceblue;
			font-size: 20px;
		}
	</style>
	
</head>
	<?php
		require("ketnoi.php");
		$loiTen="";
		$loiGia="";
		$GiaSP="";
		$loiHT="";
		$loiAnh="";
		if($_SERVER["REQUEST_METHOD"]=="POST")
		{
				$a=$_FILES['upload'];
				$b="anh/".$a['name'];
			if($b=="anh/")
			{
				$loiAnh="<span style='color: red'>Vui lòng không bỏ trống!</span>";
			}
			else{
				$a=$_FILES['upload'];
				$b="anh/".$a['name'];
			
			}
			
			if(empty($_POST['txtTen']))
			{
				$loiTen="<span style='color: red'>Vui lòng không bỏ trống!</span>";
			}
			else{
				$Ten=$_POST['txtTen'];
			}
			$GiaSP=$_POST['txtGia'];
			if($GiaSP<=1000)
			{
				$loiGia="<span style='color: red'>Giá tiền ít nhất là 1000 VNĐ</span>";
			}
			else
			{
				$Gia=$_POST['txtGia'];
				if(!preg_match("/[0-9]{9}/i",$GiaSP))
				{
					$loiGia="<span style='color:red'>Giá phải là kiểu số</span>";
				}
			}
			if($_POST['txtHT']<=0)
			{
				$loiHT="<span style='color: red'> Số lượng hàng phải từ 1 trở lên<span>";
			}
			else{
				$HangTon=$_POST['txtHT'];
			}
		}
	
	?>
	
	
	
	
	
	<?php
	if(isset($_GET['id']))
	{
		$Ma=$_GET['id'];
		$lenh1="Select * from tblsanpham where Ma='$Ma'";	
		$kq= mysqli_query($link,$lenh1) or die("Không thể lấy thông tin!");
		if(mysqli_num_rows($kq)>0)
		{
			while($row=mysqli_fetch_assoc($kq))
			{
				$anh=$row['AnhSP'];
				$ten=$row['TenSP'];
				$gia=$row['GiaSP'];
				$soluong=$row['HangTon'];
			}
		}
	}
		
	?>
<body>
	<form action="" method="post" enctype="multipart/form-data">
		<table align="center" style="margin-top: 200px">
			<tr>
				<th colspan="3" style="font-size: 25px">Sửa Thông Tin Sản Phẩm</th>
			</tr>
			<tr>
				<td class="td">Chọn Ảnh Sản Phẩm:</td><td class="td"><input  type="file" name="upload"><br><?php echo($loiAnh); ?></td>
				<td width="50px"><a href="<?=$anh?>"><img title="phóng to"  width="75px" src="<?=$anh?>"></a></td>
			</tr>
			<tr>
				 
				<td class="td">Nhập Tên Sản Phẩm:</td><td class="td"><input class="Text" value="<?=$ten ?>" type="text" name="txtTen"><br><?php echo($loiTen);  ?> </td>
			</tr>
			<tr>
				<td class="td">Nhập Giá Sản Phẩm:</td><td class="td"><input class="Text" type="text" value="<?=$gia ?>" name="txtGia"><br><?php echo($loiGia); ?></td>
			</tr>
			<tr>
				<td class="td">Nhập Số Lượng Sản Phẩm:</td><td class="td"><input class="Text" value="<?=$soluong ?>" type="text" name="txtHT"><br><?php echo($loiHT); ?></td>
			</tr>
			<tr>
				<td colspan="3" align="center"><button type="submit" id="nut" name="btnLuu">Lưu</button></td>
			</tr>
			
		</table>
		
	</form>
	<?php
		if(isset($_POST['btnLuu']))
		{
			$TenSP=$_POST['txtTen'];
			$a=$_FILES['upload'];
			
			$t=$a['tmp_name'];
			$l=$a['error'];
			$GiaSanPham=$_POST['txtGia'];
			$SLSP=$_POST['txtHT'];
			if($l==0)
			{
				move_uploaded_file($t,$b);
			
			}
			if($b!="anh/" && !empty($Ten) && !empty($Gia) && !empty($HangTon))
			{
				$lenh="Update tblsanpham Set Ma='$Ma', AnhSP='$b', TenSP='$TenSP', GiaSP='$GiaSanPham', HangTon='$SLSP' where Ma='$Ma'";
				$kq1=mysqli_query($link, $lenh);
				header("location: trangchu.php");
			}

		}
	?>
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
</body>
</html>