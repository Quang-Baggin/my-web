<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
	<style>
		table, th, tr{
			border: 1px solid black;
			border-collapse: collapse;
		}
		th{
			background-color:#47a9f7;
			font-size: 35px;
			color: aliceblue;
		}
		td{
			font-size: 20px;
			width: 300px;
			height: 50px;
		}
		.Text{
			width: 250px;
			height: 30px;
		}
		#tb{
			font-size: 18px;
			color: red;
			text-align: center;
			margin: auto
		}
		#nut{
			padding: 20px;
			background-color: #78C0F9;
			color: aliceblue;
			font-size: 20px;
		}
	</style>
	<?php
		function batloi($ktr)
		{
		
			if(empty($ktr))
			{
				$loi="<span style='color: red'>Vui lòng không bỏ trống!</span>";
			}
			else{
				$kq=$ktr;
			}
			return $kq;
		}
	?>
</head>
	<?php
		require("ketnoi.php");
		$loiTen="";
		$loiGia="";
		$GiaSP="";
		$loiHT="";
		$loiAnh="";
		if($_SERVER["REQUEST_METHOD"]=="POST")
		{
				$a=$_FILES['upload'];
				$b="anh/".$a['name'];
			if($b=="anh/")
			{
				$loiAnh="<span style='color: red'>Vui lòng không bỏ trống!</span>";
			}
			else{
				$a=$_FILES['upload'];
				$b="anh/".$a['name'];
			
			}
			
			if(empty($_POST['txtTen']))
			{
				$loiTen="<span style='color: red'>Vui lòng không bỏ trống!</span>";
			}
			else{
				$Ten=$_POST['txtTen'];
			}
			$GiaSP=$_POST['txtGia'];
			if($GiaSP<=1000)
			{
				$loiGia="<span style='color: red'>Giá tiền ít nhất là 1000 VNĐ</span>";
			}
			else
			{
				$Gia=$_POST['txtGia'];
				if(!preg_match("/[0-9]{9}/i",$GiaSP))
				{
					$loiGia="<span style='color:red'>Giá phải là kiểu số</span>";
				}
				
			}
			if($_POST['txtHT']<=0)
			{
				$loiHT="<span style='color: red'> Số lượng hàng phải từ 1 trở lên<span>";
			}
			else{
				$HangTon=$_POST['txtHT'];
			}
		}
	
	?>

<body>
	<form action="" method="post" enctype="multipart/form-data">
		<table align="center" style="margin-top: 200px">
			<tr>
				<th colspan="2" style="font-size: 35px">Thêm Sản Phẩm</th>
			</tr>
			<tr>
				<td>Chọn Ảnh Sản Phẩm:</td><td><input  type="file" name="upload"><br><?php echo($loiAnh); ?></td>
			</tr>
			<tr>
				
				<td>Nhập Tên Sản Phẩm:</td><td><input class="Text" type="text" placeholder="Tên sản phẩm" name="txtTen"><br><?php echo($loiTen);  ?>  </td>
			</tr>
			<tr>
				<td>Nhập Giá Sản Phẩm:</td><td><input class="Text" type="text" placeholder="Giá sản phẩm" name="txtGia"><br><?php echo($loiGia); ?></td>
			</tr>
			<tr>
				<td>Nhập Số Lượng Sản Phẩm:</td><td><input class="Text" placeholder="Số lượng hàng" type="text" name="txtHT"><?php echo($loiHT); ?></td>
			</tr>
			<tr>
				<td colspan="2" align="center"><button type="submit" id="nut" name="btnLuu"><b>Thêm</b></button></td>
			</tr>
			
		</table>
		
	</form>
	<?php
		if(isset($_POST['btnLuu']))
		   {
			$a=$_FILES['upload'];
				$t=$a['tmp_name'];
				$l=$a['error'];
			
				   if($l==0)
					{

						move_uploaded_file($t,$b);

					}
			   
				
				if($b!="anh/" && !empty($Ten) && !empty($Gia) && !empty($HangTon)){
					$lenh="Insert Into tblsanpham Values('', '$b', '$Ten', '$Gia', '$HangTon')";
					$kq=mysqli_query($link,$lenh) or die("Thêm không thành công!");
					header("location: trangchu.php");
				}
				else{
					echo("<span id='tb'>Thêm ko thành công!</span>");
				}
					
				
				
		   }
	?>
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
</body>
</html>