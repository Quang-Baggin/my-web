<?php
	$link= new mysqli('localhost', 'root', '', 'dbtcg') or die("Kết nối ko thành công");
?>