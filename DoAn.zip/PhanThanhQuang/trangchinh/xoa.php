<?php
	require("ketnoi.php");
	if(isset($_GET['id']))
	{
		$Ma=$_GET['id'];
		$lenh="Delete from tblsanpham where Ma='$Ma'";
		$kq=mysqli_query($link, $lenh) or die("Xóa Không Thành Công");
		header("location: trangchu.php");
	}
?>