<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
	<style>
		 table{
			border: 1px solid black;
			border-collapse: collapse;
			 border-radius: 5px; 
			box-shadow: 3px 3px 3px #AAA;
			
		}
		th{
			background-color:#47a9f7;
			font-size: 35px;
			color: aliceblue;
		}
		td{
			font-size: 20px;
			width: 300px;
			padding: 10px;
			height: 50px;
		}
		.Text{
			width: 95%;
			height: 30px;
			padding: 5px;
		}
		#nut{
			padding: 5px;
			font-size: 20px;
			width: 100%;
			background-color: #78C0F9;
			color: aliceblue;
		}
		#nutdk{
			margin:0;
		}
	</style>
</head>

<body>
	
		<?php
				$loi="";
			if(isset($_POST['btnDN']))
			{
				$mkTest="";
				require("connect.php");
				$TKdn=$_POST['txtTen'];
				$MKdn=$_POST['txtMK'];
				
				$lenh="Select *from tblnguoidung where TaiKhoan='$TKdn'";
				$kq=mysqli_query($link, $lenh);
				if(mysqli_num_rows($kq)>0)
				{
					while($row=mysqli_fetch_assoc($kq))
					{
						$mkTest=$row['MatKhau'];
					}
				}
				if(password_verify($MKdn, $mkTest))
				{
					header("location: trangchinh/trangchu.php");
				}
				else{
					$loi="<span style='color: red'>Mật khẩu hoặc tài khoản không hợp lệ!</span>";
				}
			}
		
		?>
	<form action="" method="post" enctype="multipart/form-data">
		<table align="center" style="margin-top: 200px">
			<tr>
				<th >ĐĂNG NHẬP</th>
			
			</tr>
			<tr>
				
				<td><input class="Text" type="text" placeholder="Tên tài khoản" name="txtTen"><?php echo($loi)?></td>
				
			</tr>
			<tr>
				
				<td><input class="Text" placeholder="Mật khẩu" type="password" name="txtMK"><?php echo($loi)?></td>
			</tr>
			<tr>
				<td><button id="nut" type="submit" name="btnDN">Đăng Nhập</button></td>
			</tr>
			<tr>
				<td><a id="nutdk" href="dangky.php" style="color: cornflowerblue">Đăng Ký?</a></td>
			</tr>
		
		</table>
	
	
	</form>
</body>
</html>