<!doctype html>
<html>
<?php
	ob_start();
	require("ketnoi.php");
?>
<head>
  <meta charset="utf-8">
  <title>Saigon TCG-Yu-Gi-Oh! - Digimon & Phụ kiện Card Game</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  
  <link rel="stylesheet" href="dinhdang.css">
	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
 <?php
	
	function mysubstr($str,$limit=25){
		if(strlen($str)<=$limit) return $str;
		return mb_substr($str,0,$limit-3,'UTF-8').'...';
	}
	function vonglap($lenh1){
		$link= new mysqli("localhost", "root", "", "dbtcg");
		$results=mysqli_query($link, $lenh1);
		$data=[];
		while($row = mysqli_fetch_array($results,1))
		{
			$data[]=$row;
		}
		
	}
	
?>
	<style>
		#chucuoitrang{
			padding-bottom: 10px;
			padding-top: 10px;
			color: #777777;
			margin-left: -100px;
		}
	
		.to-top {
    font-size: 25px;
    position: absolute;
    top: 10px;
    right: 30px;
    color: #444;
    display: block;
}

	</style>
</head>


<body>
  <!--đầu trang-->
  <div class="container-fluid" style="background-color: #78C0F9 ">
    <div id="thuocxanh">

    </div>

  </div>
  <div class="container-fluid" style="background-color: #f5f5f5">
    <div class="row">
      <div class="col-md-4" style="color: #777777">
        <span style="font-size: 19px">Yu-Gi-Oh! - Digimon & Phụ kiện Card Game</span>
      </div>
      <div class="col-md-5"></div>
      <div class="col-md-3">
        <a href="https://saigontcg.com/my-account" class="discoloration">Tài Khoản</a> <span
          style="color: gray">|</span>
        <a href="https://saigontcg.com/lien-he" class="discoloration">Liên Hệ</a> <span style="color: gray">|</span>
        <a href="https://saigontcg.com/cach-thuc-mua-hang" class="discoloration">Cách Thức Mua Hàng</a>
      </div>
    </div>
  </div>
  <div class="container-fluid">
    <div class="row">
      <br><br>

    </div>
  </div>
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-5">
        <a href="https://saigontcg.com"><img src="anh/logo.jpg"
            width="80%"></a>
      </div>
      <div class="col-md-4">
        <input type="search" class="search-field" placeholder="Search for products">
        <button class="btnsearch" style="background-color: #78C0F9"><i style="color: white"
            class="fa fa-search"></i></button>
      </div>
      <div class="col-md-3">

        <a href="https://saigontcg.com/cart" title="View your shopping cards"><img src="anh/Capture.JPG"
            width="40%"></a>
      </div>
    </div>
  </div>
  <!--menu-->
  <div id="thantrang">
    <div class="hienmenu">
      <div class="container-fluid">
        <div id="navbar">
          <a href="https://saigontcg.com" style="color: #f2f2f2"><i class=" fa fa-home" aria-hidden="true"></i>TRANG
            CHỦ</a>
          <div class="atrongmenu">
            <div class="dropdown">
              <span>SẢN PHẨM YU-GI-OH</span>
              <div class="dropdown-content">
                <a href="https://saigontcg.com/product-category/sealed-products/structure-deck-sealed-products"
                  style="text-align: left" class="discoloration">YU-GI-OH! STRUCTUER DECK</a>
                <a href="https://saigontcg.com/product-category/sealed-products/booster-pack-sealed-products"
                  style="text-align: left" class="discoloration">YU-GI-OH! BOOSTER</a>
                <a href="https://saigontcg.com/product-category/sealed-products/box-sealed-products"
                  style="text-align: left" class="discoloration">YU-GI-OH! COLLECTION</a>
              </div>
            </div>
          </div>
          <div class="atrongmenu">
            <div class="dropdown">
              <span>SẢN PHẨM DIGIMON</span>
              <div class="dropdown-content">
                <a href="https://saigontcg.com/product-category/digimon/single-dgm" style="text-align: left"
                  class="discoloration">DIGIMON SINGLE CARD</a>
                <a href="https://saigontcg.com/product-category/digimon/starter-deck-dgm" style="text-align: left"
                  class="discoloration">DIGIMON STARTER DECK</a>
                <a href="https://saigontcg.com/product-category/sealed-products/box-sealed-products"
                  style="text-align: left" class="discoloration">DIGIMON BOOSTER</a>
                <a href="https://saigontcg.com/product-category/digimon/dgm-collection" style="text-align: left"
                  class="discoloration">DIGIMON COLLECTION</a>
              </div>
            </div>
          </div>
          <div class="atrongmenu">
            <div class="dropdown">
              <span>SẢN PHẨM ONE PIECE</span>
              <div class="dropdown-content">
                <a href="https://saigontcg.com/product-category/one-piece/one-piece-single-card"
                  style="text-align: left" class="discoloration">ONE PIECE SINGLE CARD</a>
                <a href="https://saigontcg.com/product-category/one-piece/one-piece-starter-deck"
                  style="text-align: left" class="discoloration">ONE PIECE STARTER DECK</a>
                <a href="https://saigontcg.com/product-category/one-piece/one-piece-booster" style="text-align: left"
                  class="discoloration">ONE PIECE BOOSTER</a>

              </div>
            </div>
          </div>
          <div class="atrongmenu">
            <div class="dropdown">
              <span>SẢN PHẨM SHADOWNVERSE</span>
              <div class="dropdown-content">

                <a href="https://saigontcg.com/product-category/shadowverse-evolve/shadowverse-starter-deck"
                  style="text-align: left" class="discoloration">SHADOWNVERSE STARTER DECK</a>
                <a href="https://saigontcg.com/product-category/shadowverse-evolve/shadowverse-booster"
                  style="text-align: left" class="discoloration">SHADOWNVERSE BOOSTER</a>

              </div>
            </div>
          </div>
          <div class="atrongmenu">
            <div class="dropdown">
              <span>PHỤ KIỆN</span>
              <div class="dropdown-content">
                <a href="https://saigontcg.com/product-category/sealed-products/sleeves-sealed-products"
                  style="text-align: left" class="discoloration">SLEEVES</a>
                <a href="https://saigontcg.com/product-category/sealed-products/deck-box-sealed-products"
                  style="text-align: left" class="discoloration">DECK BOX</a>
                <a href="https://saigontcg.com/product-category/sealed-products/binder-album-sealed-products"
                  style="text-align: left" class="discoloration">ALBUM</a>
                <a href="https://saigontcg.com/product-category/sealed-products/playmat" style="text-align: left"
                  class="discoloration">PLAY MAT</a>
                <a href="https://saigontcg.com/product-category/dice" style="text-align: left" class="discoloration">XÍ
                  NGẦU</a>
                <a href="https://saigontcg.com/product-category/sealed-products/field-center" style="text-align: left"
                  class="discoloration">FIELD CENTER</a>


              </div>
            </div>
          </div>
          <div class="atrongmenu">
            <div class="dropdown">
              <span>KHÁC</span>
              <div class="dropdown-content">
                <a href="https://saigontcg.com/product-category/sealed-products/set-card" style="text-align: left"
                  class="discoloration">SET CARD</a>
                <a href="https://saigontcg.com/product-category/bandai" style="text-align: left"
                  class="discoloration">BANDAI</a>
                <a href="https://saigontcg.com/product-category/ygo-ss2" style="text-align: left"
                  class="discoloration">YGO
                  SS2</a>
                <a href="https://saigontcg.com/product-category/collection" style="text-align: left"
                  class="discoloration">HÀNG SƯU TẬP KHÁC</a>
                <a href="https://saigontcg.com/product-category/sealed-products/combo" style="text-align: left"
                  class="discoloration">COMBO SET</a>



              </div>
            </div>
          </div>
          <div class="atrongmenu">
            <div class="dropdown">
              <span>CÁC ƯU ĐÃI</span>
              <div class="dropdown-content">
                <a href="https://saigontcg.com/ma-giam-gia" style="text-align: left" class="discoloration">MÃ GIẢM
                  GIÁ</a>
                <a href="https://saigontcg.com/dang-giam-gia" style="text-align: left" class="discoloration">SẢN PHẨM
                  GIẢM
                  GIÁ</a>



              </div>
            </div>
          </div>
        </div>
      </div>
    </div><br>
   <!--thân trang-->
    <div class="w3-content w3-display-container">
      <img class="mySlides" src="anh/BANNER1.jpg" style="width:100%">
      <a href="https://www.facebook.com/saigontcg"><img class="mySlides" src="anh/BANNER2.jpg" style="width:100%"></a>


      <button class="w3-button w3-black w3-display-left" onclick="plusDivs(-1)">&#10094;</button>
      <button class="w3-button w3-black w3-display-right" onclick="plusDivs(1)">&#10095;</button>
    </div>
    <!--Nội dung-->
    <br><br><br>
	 <form action="" method="post" enctype="multipart/form-data">
    <div class="container-fluid">
      <div class="row">

        <div class="col-md-4">
          <div class="container-fluid">
            <h4 class="gachchan"><b>SẢN PHẨM YU-GI-OH! CARD GAME</b></h4>
            <ul>
              <li class="nut"><a
                  href="https://saigontcg.com/product-category/sealed-products/structure-deck-sealed-products"
                  class="doimauds"> Yu-Gi-Oh! Structure Deck</a></li>
              <li class="nut"><a
                  href="https://saigontcg.com/product-category/sealed-products/booster-pack-sealed-products"
                  class="doimauds"> Yu-Gi-Oh! Booster</a></li>
              <li class="nut"><a href="https://saigontcg.com/product-category/sealed-products/box-sealed-products"
                  class="doimauds"> Yu-Gi-Oh! Collection</a></li>

            </ul>
          </div>
          <br><br>
          <div class="container-fluid">
            <h4 class="gachchan"><b>SẢN PHẨM DIGIMON CARD GAME</b></h4>
            <ul>
              <li class="nut"><a href="https://saigontcg.com/product-category/digimon/starter-deck-dgm"
                  class="doimauds"> Digimon Starter Deck</a></li>
              <li class="nut"><a href="https://saigontcg.com/product-category/digimon/booster-dgm" class="doimauds">
                  Digimon Booster</a></li>
              <li class="nut"><a href="https://saigontcg.com/product-category/digimon/collection-dgm" class="doimauds">
                  Digimon Collection</a></li>

            </ul>
          </div>
          <br><br>
          <div class="container-fluid">
            <h4 class="gachchan"><b>SẢN PHẨM ONE PIECE CARD GAME</b></h4>
            <ul>
              <li class="nut"><a href="https://saigontcg.com/product-category/one-piece/one-piece-starter-deck"
                  class="doimauds"> One Piece Starter Deck</a></li>
              <li class="nut"><a href="https://saigontcg.com/product-category/one-piece/one-piece-booster"
                  class="doimauds"> One Piece Booster</a></li>
              <li class="nut"><a href="https://saigontcg.com/product-category/one-piece/one-piece-collection"
                  class="doimauds"> One Piece Collection</a></li>

            </ul>
          </div>
          <br><br>
          <div class="container-fluid">
            <h4 class="gachchan"><b>PHỤ KIỆN</b></h4>
            <ul>
              <li class="nut"><a href="https://saigontcg.com/product-category/sealed-products/sleeves-sealed-products"
                  class="doimauds"> Sleeves</a></li>
              <li class="nut"><a href="https://saigontcg.com/product-category/sealed-products/deck-box-sealed-products"
                  class="doimauds">Deck Box</a></li>
              <li class="nut"><a
                  href="https://saigontcg.com/product-category/sealed-products/binder-album-sealed-products"
                  class="doimauds">Binder (Album)</a></li>
              <li class="nut"><a href="https://saigontcg.com/product-category/sealed-products/playmat"
                  class="doimauds">Playmat</a></li>
              <li class="nut"><a href="https://saigontcg.com/product-category/dice" class="doimauds">Xí Ngầu</a></li>
              <li class="nut"><a href="https://saigontcg.com/product-category/sealed-products/field-center"
                  class="doimauds">Field Center</a></li>
            </ul>
          </div>
          <br><br>
          <div class="container-fluid">
            <h4 class="gachchan"><b>CÁC SẢN PHẨM KHÁC</b></h4>
            <ul>
              <li class="nut"><a href="https://saigontcg.com/product-category/sealed-products/set-card"
                  class="doimauds">Set Card</a></li>
              <li class="nut"><a href="https://saigontcg.com/product-category/sealed-products/combo"
                  class="doimauds">Combo Set</a></li>
              <li class="nut"><a href="https://saigontcg.com/product-category/bandai" class="doimauds">Bandai Card</a>
              </li>
              <li class="nut"><a href="https://saigontcg.com/product-category/ygo-ss2" class="doimauds">Yu-Gi-Oh! SS
                  2</a></li>
              <li class="nut"><a href="https://saigontcg.com/product-category/dice" class="doimauds">Hàng Sưu Tập
                  Khác</a></li>
            </ul>
          </div>
          <br>
        </div>
		
		
        <div class="col-md-8">
          <div class="container-fluid">
            <h6 style="margin-bottom: 36px"><b>Sản phẩm sẽ cập nhật liên tục</b></h6>
            <div class="row">
              <div class="col-md-4">
                <select class="luachon">
                  <option>Sản phẩm mới cập nhật</option>
                  <option>Thứ tự theo mức độ phổ biến</option>
                  <option>Mới nhất</option>
                  <option>Thứ tự theo giá: thấp đến cao</option>
                  <option>Thứ tự theo giá: cao đến thấp</option>
                </select>
                
              </div>
              <div class="col-md-3" id="gionghang">
                <a id="afilter" href="#" >More Filters …</a>
              </div>
              <div class="col-md-3">
                <select id="luachon2">
                  <option>12 products per page</option>
                  <option>20 products per page</option>
                  <option>40 products per page</option>
                  <option>80 products per page</option>
                  <option>200 products per page</option>
                </select>
              </div>
              <div class="col-md-2">
               <span id="chunho"> Showing 1–12 of 19326 result</span>
              </div>
            </div>
          </div>
          <hr>
			<div class="container">
			<div class="row">
				<?php 
					$lenh1="Select count(Ma) as number from tblsanpham"	;
					$kq1=mysqli_query($link, $lenh1);
					$mang=[];
					if(mysqli_num_rows($kq1)>0)
					{
						while($row= mysqli_fetch_array($kq1,1))
						{
							$mang[]=$row;
						}
						$so=$mang[0]['number'];
						$page = ceil($so/8);
					}
					$trang_hientai=1;
					if(isset($_GET['page']))
					{
						$trang_hientai=$_GET['page'];
					}
					$trangtt=($trang_hientai-1)*8;
				
					$lenh="Select *from tblsanpham limit $trangtt,8";
					$kq=mysqli_query($link, $lenh);
					while($tblsanpham = mysqli_fetch_assoc($kq))
					{
						$MaSanPham=$tblsanpham['Ma'];
						echo('<div class="col-md-4" style="margin-top: 15px">
						<img src="'.$tblsanpham['AnhSP'].'" width="100%">	
						<p class="tensp">'.mysubstr($tblsanpham['TenSP']).'</p>
						<p class="giasp"><b>'.$tblsanpham['GiaSP'].' VNĐ</b></p>
						<p class="hangton">'.$tblsanpham['HangTon'].' left in stock</p>
						<div align="center">
						<a class="atrongdb doimauft" href="xoa.php?id='.$MaSanPham.'">Xóa</a> | <a class="atrongdb doimauft" href="sua.php?id='.$MaSanPham.'">Sửa</a></div>
					</div>');	
					}
				?>
			<hr>
			</div>  
				<div class="row" style="margin-top: 15px"> 
					<button type="submit" style="margin: auto" name="btnThem">Thêm</button>
				</div>
			<div class="row" align="right">
			 <ul class="pagination">
				  
				 <?php
					 for($i=1; $i<= $page; $i++)
					 {
							echo('<li class="list"><a href="?page='.$i.'">'.$i.'</a></li>');
					 }
				 
				 ?>
				
  				</ul>
			</div>
				<hr>
		</div>
        </div>
      </div>

    </div>
</form>
	<?php
	 	if(isset($_POST['btnThem'])) 
		{
			header("location: them.php");
		}
	  
	 ?>
   
  </div>
	<!--Chân Trang-->
	
	<div class="container-fluid" id="chantrang">
		
		<div class="row" style="padding: 10px">
			<div class="col-md-3" style="padding-top: 30px">
				<a href="https://www.facebook.com/saigontcg" class="doimauaf"><h3><b>THEO DÕI SHOP TẠI:</b></h3></a>
				<div class="anhct">
					<div class="row">
						<div class="col-md-3">
						<a href="https://www.facebook.com/saigontcg"><img src="https://scontent.xx.fbcdn.net/v/t39.30808-1/304812991_473965384745294_1186443188504502423_n.jpg?stp=cp0_dst-jpg_p50x50&_nc_cat=105&ccb=1-7&_nc_sid=5f2048&_nc_ohc=hh4nfMbBKQwAX-Nl6UJ&_nc_oc=AQk58Il0kViQ65GBb2Qq1v-yaA7uAkOkS5APiSGaREqFO3mFrLX3UwDxnw8is7XEHdY&_nc_ht=scontent.xx&edm=AEDRbFQEAAAA&oh=00_AfBZ8KwTQixEk-HUi2WfEVdzkZhDhljpe8V4aE-pO1y5FA&oe=655A46E6" width="80%" id="atronga"></a>
						</div>
						<div class="col-md-9">
							<a href="https://www.facebook.com/saigontcg" class="linktrongct">Saigon Trading Card Games (saigontcg)</a>
							<h5 style="color: white">10,297 followers</h5>
						</div>	
						
						<div class="col-md-6" style="margin-top: 70px">
							<a href="https://www.facebook.com/saigontcg" class="linktrongct2"><i class="fa-brands fa-square-facebook fa-2xl" style="color: #6090e1;"></i> Follow Page</a>
						</div>
						<div class="col-md-6" style="margin-top: 70px">
							<a href="https://www.facebook.com/saigontcg" class="linktrongct3"><i class="fa-brands fa-shopify fa-2xl" style="color: #b5b5b5;"></i> Shop on Website</a>
						</div>
					</div>
					
				</div>
			</div>
			<div class="col-md-3"style="padding-top: 30px"> 
				<h3 style="color:aliceblue"><b>SÀN TMĐT LIÊN KẾT:</b></h3>
				<a href="https://shopee.vn/saigontcg"><img src="https://saigontcg.com/wp-content/uploads/shopeeshop-1.jpg" width="100%"></a>
			</div>
		</div>
		<div class="row" style="padding-bottom: 100px">
			<div class="col-md-3">
			
		
			<a href="https://www.facebook.com/saigontcg">
			<div class="container" style="background-image: url(https://inkythuatso.com/uploads/thumbnails/800/2022/03/anh-dai-dien-facebook-mau-den-1-29-11-34-09.jpg)">
				<br><br><br><br><br><br><br>
			</div></a>
		</div>	
		</div>
	
	</div>
	<!--kết thúc-->
	<div class="container-fluid">
		<div class="container">
			<span id="chucuoitrang">© Copyright 2018 SaigonTCG · Designed by ducminh</span>
			<a href="#" class="to-top" ><i class="fa fa-arrow-circle-o-up"></i></a>
		</div>
	
	</div>
  <script>
    var slideIndex = 1;
    showDivs(slideIndex);

    function plusDivs(n) {
      showDivs(slideIndex += n);
    }

    function showDivs(n) {
      var i;
      var x = document.getElementsByClassName("mySlides");
      if (n > x.length) { slideIndex = 1 }
      if (n < 1) { slideIndex = x.length }
      for (i = 0; i < x.length; i++) {
        x[i].style.display = "none";
      }
      x[slideIndex - 1].style.display = "block";
    }
  </script>
  <script>
    window.onscroll = function () { myFunction() };

    var navbar = document.getElementById("navbar");
    var sticky = navbar.offsetTop;

    function myFunction() {
      if (window.pageYOffset >= sticky) {
        navbar.classList.add("sticky")
      } else {
        navbar.classList.remove("sticky");
      }
    }
  </script>










<?php
	ob_end_flush(); 
	?>



</body>

</html>