<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Đăng ký tài khoản</title>
	<style>
		 table{
			border: 1px solid black;
			border-collapse: collapse;
			 border-radius: 5px; 
			box-shadow: 3px 3px 3px #AAA;
			
		}
		th{
			background-color:#47a9f7;
			font-size: 35px;
			color: aliceblue;
		}
		td{
			font-size: 20px;
			width: 300px;
			padding: 10px;
			height: 50px;
		}
		.Text{
			width: 95%;
			height: 30px;
			padding: 5px;
		}
		#nut{
			padding: 5px;
			font-size: 20px;
			width: 100%;
			background-color: #78C0F9;
			color: aliceblue;
		}
		#nutdk{
			margin-left: 160px;
			padding: 10px;
		}
		.luachon{
			width: 200px;
			height: 50px;
		}
	</style>
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
	<link rel="stylesheet" href="dangky.css">

	<link rel="stylesheet" href="dinhdang.css">
</head>
<style>
	.tieudeC {
  text-align: center;
  color: whitesmoke;
  margin-top: 20px;
		
	}
	.lienhe{
		color:aliceblue;
		text-align: justify;
	}
	.tieude {
  color: aliceblue;
  margin: 0;
	align-items: center;  
   text-align: center;
    position: absolute;
    left: 36%;
    transform: translateX(-64%);
	
	}
	</style>
<body>
	<!--Header-->
<div class="container-fluid" style="background-color: #2D568E">
	<br>
	<div class="row align-items-center">
	<div class="col-md-3">
  		<img class="logo" src="https://startupwheel.vn/wp-content/uploads/2021/04/hutech-university-logo.jpg" alt="Logo Hutech">
	</div>
	<div class="col-md-9">
  		<h1 class="tieude">WINTER IS COMING</h1>
	</div>
</div>
	<br>
	
</div>
	<!--END_Header-->
	<form action="" method="post" enctype="multipart/form-data">
		<table align="center" style="margin-top: 100px">
			<tr><th><h4 style="text-align: center">Đăng Ký Tài Khoản</h4></th></tr>
			<tr>
				
				<td><input class="Text"  placeholder="Tên tài khoản" type="text" name="txtTK"></td>
			</tr>
			<tr>
				
				<td><input placeholder="Họ tên người dùng" class="Text" type="text" name="txtTen"></td>
			</tr>
			<tr>
				
				<td><input type="password" class="Text" placeholder="Mật khẩu" name="txtMK"></td>
			</tr>
			<tr>
				<td>Quyền Người Dùng:</td></tr>
			<tr>
				<td><select name="cbbQ" class="luachon">
					<option class="luachon" value="1">Admin</option>
					<option class="luachon" value="2">User</option>
					</select></td>
			</tr>
			<tr><td><button  type="submit" name="btnLuu">Lưu</button><button id="nutdk" type="submit" name="btnDN" >Đăng Nhập</button></td> </tr>
		</table>
		<?php
		if(isset($_POST['btnDN']))
		{
			header("location: dangnhap.php");
		}
			if(isset($_POST['btnLuu']))
			{
				require("connect.php");
				$Quyen="";
				if($_POST['cbbQ']==1)
				{
					$Quyen="Admin";
				}
				else{
					$Quyen="User";
				}
				$TK=$_POST['txtTK'];
				$Ten=$_POST['txtTen'];
				$MK=password_hash($_POST['txtMK'], PASSWORD_DEFAULT);
				
				$lenh="Insert into tblnguoidung values('$TK', '$Ten', '$MK', '$Quyen')";
				$kq = mysqli_query($link, $lenh) or die("Đăng ký thất bại!");
				echo("Đăng ký thành công!");
			}
		
		?>
	
	</form>
	<br><br>
	<!--chan6trang-->
	<div class="container-fluid" style="background-color: #2A2725" >
		<div class="row" >
			<div class="col-12 text-center"><h2 class="tieudeC" >Liên Hệ Chúng Tôi</h2></div>
		</div>
		
			<h6 class="lienhe">Nếu bạn phát hiện vấn đề hãy nói với chúng tôi:</h6>
			<h6 class="lienhe">Email: saigontcg@gmail.com</h6>
			<h6 class="lienhe">Hotline saigonTCG: 111 (miễn phí)</h6>
			<h6 class="lienhe">Facebook: facebook.com/SaigonTCG</h6>
		<br>
	</div>
</body>
</html>