<!doctype html>
<html>
<head>
<meta charset="utf-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Đăng Nhập</title>
	<link rel="stylesheet" href="dangnhap.css">
</head>

<body>
	
		<?php
				$loi="";
			if(isset($_POST['btnDN']))
			{
				$mkTest="";
				require("connect.php");
				$TKdn=$_POST['txtTen'];
				$MKdn=$_POST['txtMK'];
				
				$lenh="Select *from tblnguoidung where TaiKhoan='$TKdn'";
				$kq=mysqli_query($link, $lenh);
				if(mysqli_num_rows($kq)>0)
				{
					while($row=mysqli_fetch_assoc($kq))
					{
						$mkTest=$row['MatKhau'];
					}
				}
				if(password_verify($MKdn, $mkTest))
				{
					header("location: trangchinh/trangchu.php");
				}
				else{
					$loi="<span style='color: red'>Mật khẩu hoặc tài khoản không hợp lệ!</span>";
				}
			}
		
		?>
	<div class="login-container">

        <div class="login-box">

            <h1>Đăng nhập</h1>

            <p class="welcome">
                Chào mừng bạn quay trở lại!
            </p>
            
            <form action="" method="post">

                <div class="input-group">
                    <label for="txtTen">Tên tài khoản</label>
                    <input
                        type="text"
                        id="txtTen"
                        name="txtTen"
                        placeholder="Nhập tên tài khoản">
                </div>

                <div class="input-group">
                    <label for="txtMK">Mật khẩu</label>
                    <input
                        type="password"
                        id="txtMK"
                        name="txtMK"
                        placeholder="Nhập mật khẩu">
                </div>

                <button type="submit" name="btnDN">
                    Đăng nhập
                </button>

            </form>

            <div class="register">
                Chưa có tài khoản?
                <a href="dangky.php">Đăng ký ngay</a>
            </div>

        </div>

    </div>
</body>
</html>